package app.shilex.android.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MoodTest {
    @Test
    fun hasThirtyOrMoreMoods() {
        assertTrue("moods: ${Mood.entries.size}", Mood.entries.size >= 30)
    }

    @Test
    fun keysAndMainColoursAreUnique() {
        assertEquals(Mood.entries.size, Mood.keys.toSet().size)
        assertEquals(Mood.entries.size, Mood.entries.map { it.main.value }.toSet().size)
    }

    @Test
    fun everyKeyIsFoundAgain() {
        Mood.entries.forEach { assertNotNull(Mood.of(it.key)) }
    }
}
