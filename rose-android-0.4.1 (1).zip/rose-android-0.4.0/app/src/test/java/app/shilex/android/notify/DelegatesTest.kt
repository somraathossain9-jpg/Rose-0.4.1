package app.shilex.android.notify

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DelegatesTest {
    private val key = "com.whatsapp|Rahul"

    @Test
    fun aHandedOverChatIsRememberedForOnePersonOnly() {
        val d = AutoReplyRules.Delegates()
        d.add(key, "he will call at 5", now = 1_000L)
        assertTrue(d.has(key, 2_000L))
        assertEquals("he will call at 5", d.noteOf(key, 2_000L))
        assertFalse(d.has("com.whatsapp|Mom", 2_000L))
    }

    @Test
    fun aHandOverEndsAfterItsTime() {
        val d = AutoReplyRules.Delegates(ttlMs = 10_000L)
        d.add(key, "", now = 0L)
        assertTrue(d.has(key, 9_999L))
        assertFalse(d.has(key, 10_001L))
        assertEquals("", d.noteOf(key, 10_001L))
    }

    @Test
    fun removeAndClearTakeChatsBack() {
        val d = AutoReplyRules.Delegates()
        d.add(key, "", 0L)
        d.add("com.whatsapp|Mom", "", 0L)
        assertEquals(2, d.count())
        assertTrue(d.remove(key))
        assertFalse(d.remove(key))
        d.clear()
        assertFalse(d.has("com.whatsapp|Mom", 1L))
    }

    @Test
    fun readOutNamesThePersonAndShortensLongText() {
        assertEquals("Rahul লিখেছেন: কী করছ", AutoReplyRules.readOut("Rahul", "  কী   করছ \n"))
        val long = AutoReplyRules.readOut("Rahul", "a".repeat(500), limit = 40)
        assertTrue(long.endsWith("…"))
        assertTrue(long.length <= "Rahul লিখেছেন: ".length + 40)
    }
}
