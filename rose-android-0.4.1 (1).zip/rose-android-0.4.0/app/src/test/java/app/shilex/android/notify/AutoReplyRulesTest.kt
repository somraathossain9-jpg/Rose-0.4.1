package app.shilex.android.notify

import app.shilex.android.notify.AutoReplyRules.Action
import app.shilex.android.notify.AutoReplyRules.Turn
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AutoReplyRulesTest {
    @Test
    fun parsesAReplyDecision() {
        val d = AutoReplyRules.parse("""{"action":"reply","reply":"ওনাকে জানাচ্ছি","urgency":0,"summary":"asks if free"}""")!!
        assertEquals(Action.Reply, d.action)
        assertEquals("ওনাকে জানাচ্ছি", d.reply)
        assertEquals("asks if free", d.summary)
    }

    @Test
    fun parsesSkipAndUrgentAndFences() {
        assertEquals(Action.Skip, AutoReplyRules.parse("""{"action":"skip","reply":"","summary":""}""")!!.action)
        val urgent = AutoReplyRules.parse("```json\n{\"action\":\"urgent\",\"reply\":\"ok\",\"urgency\":3,\"summary\":\"accident\"}\n```")!!
        assertEquals(Action.Urgent, urgent.action)
        assertEquals(3, urgent.urgency)
    }

    @Test
    fun highUrgencyUpgradesAReply() {
        assertEquals(Action.Urgent, AutoReplyRules.parse("""{"action":"reply","reply":"hi","urgency":3,"summary":"x"}""")!!.action)
    }

    @Test
    fun plainTextIsTakenAsAReplyAndGarbageIsNot() {
        assertEquals("Hello there", AutoReplyRules.parse("Hello there")!!.reply)
        assertNull(AutoReplyRules.parse("{not json"))
        assertNull(AutoReplyRules.parse("   "))
    }

    @Test
    fun guardRefusesLinksNumbersAndSecrets() {
        assertNull(AutoReplyRules.sanitize("Open https://evil.example/pay now"))
        assertNull(AutoReplyRules.sanitize("Visit www.site.com"))
        assertNull(AutoReplyRules.sanitize("Call him on 01712345678"))
        assertNull(AutoReplyRules.sanitize("তার নম্বর ০১৭১২৩৪৫৬৭৮"))
        assertNull(AutoReplyRules.sanitize("His OTP is hidden"))
        assertNull(AutoReplyRules.sanitize("বিকাশে টাকা পাঠান"))
        assertNull(AutoReplyRules.sanitize(""))
    }

    @Test
    fun guardKeepsNormalRepliesTidy() {
        assertEquals("He is busy, I will tell him.", AutoReplyRules.sanitize("\"He is busy,\nI will tell him.\""))
        assertEquals("ওনাকে জানিয়ে দিচ্ছি।", AutoReplyRules.sanitize("ওনাকে জানিয়ে দিচ্ছি।"))
        assertEquals("I will tell him at 5", AutoReplyRules.sanitize("I will tell him at 5"))
        assertTrue(AutoReplyRules.sanitize("a".repeat(900))!!.length <= AutoReplyRules.MAX_REPLY)
    }

    @Test
    fun closersNeedNoAnswer() {
        listOf("ok", "Okay!", "thanks", "Thank you.", "👍", "🙏🙏", "ধন্যবাদ", "ঠিক আছে", "আচ্ছা", "", "hmm").forEach {
            assertTrue("'$it'", AutoReplyRules.isCloser(it))
        }
        listOf("ok but call me", "where are you", "কোথায় আছেন?", "urgent please").forEach {
            assertFalse("'$it'", AutoReplyRules.isCloser(it))
        }
    }

    @Test
    fun historyAlternatesAndEndsWithThem() {
        val turns = listOf(
            Turn(true, "intro"), Turn(false, "a"), Turn(false, "b"), Turn(true, "r1"), Turn(true, "r2"), Turn(false, "c"), Turn(true, "tail"),
        )
        val out = AutoReplyRules.forModel(turns)
        assertEquals(listOf(false, true, false), out.map { it.mine })
        assertEquals("a\nb", out.first().text)
        assertEquals("c", out.last().text)
        assertTrue(AutoReplyRules.forModel(listOf(Turn(true, "only mine"))).isEmpty())
    }

    @Test
    fun fallbackMirrorsTheirLanguage() {
        assertTrue(AutoReplyRules.fallback("কেমন আছেন", true).contains("রোজ"))
        assertTrue(AutoReplyRules.fallback("Hello are you there", true).startsWith("Hello! I'm Rose"))
        assertTrue(AutoReplyRules.fallback("ki khobor", false).contains("onake"))
        assertNotNull(AutoReplyRules.sanitize(AutoReplyRules.fallback("hi", false)))
        listOf(true, false).forEach { first ->
            listOf("hi there", "কেমন আছেন", "ki obostha").forEach { assertNotNull(AutoReplyRules.sanitize(AutoReplyRules.fallback(it, first))) }
        }
    }

    @Test
    fun smallMessagesGetSmallAnswers() {
        assertEquals("😂", AutoReplyRules.closerFallback("😂"))
        assertEquals("ওকে", AutoReplyRules.closerFallback("ওকে"))
        assertEquals("Ok", AutoReplyRules.closerFallback("ok"))
        assertEquals("You're welcome!", AutoReplyRules.closerFallback("Thanks!"))
        assertTrue(AutoReplyRules.closerFallback("থ্যাংকস").contains("ধন্যবাদ"))
        listOf("😂", "ok", "ধন্যবাদ", "❤").forEach { assertNotNull(AutoReplyRules.sanitize(AutoReplyRules.closerFallback(it))) }
    }
}
