package app.shilex.android.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import app.shilex.android.assistant.MoodBus
import app.shilex.android.assistant.Phase
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * ROSE's face: a glass-dark sphere made of thousands of glowing dots, with a bright rim and
 * slow ribbons of light folding across it (the look of the 0.4.0 artwork). The dots sit on a
 * Fibonacci sphere that turns once per cycle; ribbons, a travelling hot spot and the rim glow
 * take their colours from the current mood (default magenta and violet).
 *
 * Standby is one still frame (no battery cost); listening breathes and swells with the voice
 * [level] (0..1), thinking adds a turning arc, speaking moves the most. Every motion is a whole
 * number of turns per cycle, so the loop is seamless.
 */
@Composable
fun Orb(phase: Phase, modifier: Modifier = Modifier, level: Float = 0f) {
    val mood by MoodBus.mood.collectAsState()
    val accent by animateColorAsState(mood.main, tween(900), label = "accent")
    val second by animateColorAsState(mood.light, tween(900), label = "second")
    val deepColor by animateColorAsState(mood.deep, tween(900), label = "deep")
    val energy by animateFloatAsState(
        when (phase) {
            Phase.Off -> 0f
            Phase.Connecting -> 0.35f
            Phase.Listening -> 0.5f
            Phase.Speaking -> 0.9f
        },
        tween(700),
        label = "energy",
    )
    val voice by animateFloatAsState(level, spring(stiffness = Spring.StiffnessLow), label = "voice")
    val t = if (phase == Phase.Off) {
        0f
    } else {
        rememberInfiniteTransition(label = "orb").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(CYCLE_MS, easing = LinearEasing), RepeatMode.Restart),
            label = "t",
        ).value
    }

    val dots = remember { Dots(DOT_COUNT) }
    val paint = remember {
        android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            style = android.graphics.Paint.Style.STROKE
            strokeCap = android.graphics.Paint.Cap.ROUND
        }
    }

    Canvas(modifier) {
        val c = center
        val base = size.minDimension / 2 * 0.62f * (1 + 0.05f * voice)
        val a = t * 2 * PI.toFloat()
        val amp = 0.035f + 0.05f * energy + 0.11f * voice

        // Halo: the glow the sphere throws on whatever is behind it.
        drawCircle(
            Brush.radialGradient(
                listOf(accent.copy(alpha = 0.30f + 0.25f * voice + 0.10f * energy), Color.Transparent),
                c,
                base * 1.75f,
            ),
            radius = base * 1.75f,
            center = c,
        )
        // The dark glass body, so the dots read the same on a light or a dark screen.
        drawCircle(
            Brush.radialGradient(
                0f to Color(0xFF0A0230),
                0.75f to Color(0xFF05001F),
                1f to deepColor.copy(alpha = 0.85f),
                center = c,
                radius = base * 1.02f,
            ),
            radius = base * 1.01f,
            center = c,
        )

        dots.project(a, amp, energy, voice, c.x, c.y, base)
        val lit = lerp(accent, Color.White, 0.18f)
        val hot = lerp(second, Color.White, 0.55f)
        drawIntoCanvas { canvas ->
            val native = canvas.nativeCanvas
            for (bucket in 0 until BUCKETS) {
                val count = dots.counts[bucket]
                if (count == 0) continue
                val k = (bucket + 0.5f) / BUCKETS
                // Dim bodies are violet, bright ones magenta, the very brightest tip towards white.
                val color = when {
                    k < 0.55f -> lerp(deepColor, accent, k / 0.55f)
                    k < 0.85f -> lerp(accent, lit, (k - 0.55f) / 0.30f)
                    else -> lerp(lit, hot, (k - 0.85f) / 0.15f)
                }
                paint.color = color.copy(alpha = 0.25f + 0.75f * k).toArgb()
                paint.strokeWidth = (0.9f + 1.5f * k) * density * (base / (110f * density)).coerceIn(0.55f, 1.6f)
                native.drawPoints(dots.xy[bucket], 0, count * 2, paint)
            }
        }

        // The bright rim of the glass.
        drawCircle(
            Brush.radialGradient(
                0.0f to Color.Transparent,
                0.86f to Color.Transparent,
                0.97f to second.copy(alpha = 0.30f + 0.2f * energy),
                1.0f to accent.copy(alpha = 0.85f),
                center = c,
                radius = base * 1.03f,
            ),
            radius = base * 1.03f,
            center = c,
        )
        drawCircle(accent.copy(alpha = 0.55f), radius = base, center = c, style = Stroke(width = 1.2f * density))

        // Thinking: an arc chasing round the outside.
        if (phase == Phase.Connecting) {
            val ring = base * 1.18f
            rotate(t * 360f * 8) {
                drawArc(
                    Brush.sweepGradient(listOf(Color.Transparent, second, Color.Transparent), c),
                    startAngle = 0f,
                    sweepAngle = 140f,
                    useCenter = false,
                    topLeft = Offset(c.x - ring, c.y - ring),
                    size = Size(ring * 2, ring * 2),
                    style = Stroke(width = 3 * density),
                )
            }
        }
    }
}

/**
 * The dots: unit-sphere positions fixed once, projected again every frame. [xy] holds, per
 * brightness bucket, flat x,y pairs ready for Canvas.drawPoints (no per-frame allocation).
 */
private class Dots(private val n: Int) {
    private val x = FloatArray(n)
    private val y = FloatArray(n)
    private val z = FloatArray(n)
    private val lon = FloatArray(n)
    val xy = Array(BUCKETS) { FloatArray(n * 2) }
    val counts = IntArray(BUCKETS)

    init {
        val golden = PI.toFloat() * (3f - sqrt(5f))
        for (i in 0 until n) {
            val py = 1f - 2f * (i + 0.5f) / n
            val r = sqrt(max(0f, 1f - py * py))
            val th = golden * i
            x[i] = r * cos(th)
            y[i] = py
            z[i] = r * sin(th)
            lon[i] = atan2(z[i], x[i])
        }
    }

    /** [a] is the cycle angle (0..2π), [amp] how far the ribbons fold, [energy]/[voice] how alive it is. */
    fun project(a: Float, amp: Float, energy: Float, voice: Float, cx: Float, cy: Float, radius: Float) {
        counts.fill(0)
        val cosY = cos(a)
        val sinY = sin(a)
        val tilt = 0.38f
        val cosT = cos(tilt)
        val sinT = sin(tilt)
        // The hot spot wanders round the lower left, like the lit fold in the artwork.
        val hx = -0.55f + 0.25f * cos(a * 2)
        val hy = 0.55f + 0.20f * sin(a * 3)
        val hz = sqrt(max(0.05f, 1f - hx * hx - hy * hy))
        for (i in 0 until n) {
            // Two folding ribbons (whole numbers of waves, whole turns per cycle).
            val ribbon = sin(3f * lon[i] + 5f * y[i] + 2f * a) * 0.6f + sin(2f * lon[i] - 7f * y[i] - 3f * a) * 0.4f
            val ridge = ribbon.coerceIn(-1f, 1f)
            val rad = 1f + amp * ridge * (0.6f + 0.4f * sin(4f * y[i] + a))
            // Turn about the vertical axis, then tip towards the viewer.
            val rx = x[i] * cosY + z[i] * sinY
            val rz = -x[i] * sinY + z[i] * cosY
            val ry = y[i] * cosT - rz * sinT
            val rz2 = y[i] * sinT + rz * cosT
            val sx = cx + radius * rad * rx
            val sy = cy + radius * rad * ry

            val facing = rz2 // 1 front, -1 back
            val rim = (1f - abs(facing)).pow(2.2f)
            val folded = max(0f, ridge) * (0.18f + 0.30f * energy)
            val spot = max(0f, rx * hx + ry * hy + rz2 * hz).pow(14f) * (0.55f + 0.5f * voice)
            var b = 0.10f + 0.62f * rim + folded + spot
            if (facing < 0f) b *= 0.55f
            b = min(1f, b + 0.12f * voice * rim)
            val bucket = min(BUCKETS - 1, (b * BUCKETS).toInt())
            val at = counts[bucket]++ * 2
            xy[bucket][at] = sx
            xy[bucket][at + 1] = sy
        }
    }

    private fun abs(v: Float) = if (v < 0f) -v else v
}

private const val CYCLE_MS = 12_000
private const val DOT_COUNT = 1500
private const val BUCKETS = 8
