package app.shilex.android.notify

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.service.notification.NotificationListenerService
import app.shilex.android.Diag

/**
 * Keeps message alerts instant. Some phones quietly unbind a notification listener to save
 * battery, and then ROSE sees a message only when the app is next opened (minutes or hours
 * late). Every 15 minutes, and after a reboot, this checks the listener is bound and, if not,
 * asks Android to bind it again (switching the component off and on is the dependable way).
 */
class Watchdog : JobService() {
    override fun onStartJob(params: JobParameters?): Boolean {
        revive(this)
        return false
    }

    override fun onStopJob(params: JobParameters?) = true

    companion object {
        private const val JOB_ID = 4107
        private const val EVERY_MS = 15 * 60_000L

        fun schedule(context: Context) {
            val jobs = context.getSystemService(JobScheduler::class.java) ?: return
            if (jobs.getPendingJob(JOB_ID) != null) return
            val info = JobInfo.Builder(JOB_ID, ComponentName(context, Watchdog::class.java))
                .setPeriodic(EVERY_MS)
                .setPersisted(true)
                .build()
            runCatching { jobs.schedule(info) }.onFailure { Diag.w("watchdog: could not schedule") }
        }

        /** Rebinds the listener if the user allowed it but Android has dropped it. */
        fun revive(context: Context) {
            if (!NotificationWatch.allowed(context) || NotificationWatch.connected) return
            Diag.i("watchdog: listener not bound, reviving")
            val me = ComponentName(context, NotificationWatch::class.java)
            runCatching {
                val pm = context.packageManager
                pm.setComponentEnabledSetting(me, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
                pm.setComponentEnabledSetting(me, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
            }
            runCatching { NotificationListenerService.requestRebind(me) }
        }
    }
}
