package app.shilex.android

import android.Manifest
import android.app.KeyguardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.PowerManager
import app.shilex.android.data.Settings
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import app.shilex.android.assistant.AssistantViewModel
import app.shilex.android.assistant.VoiceService
import app.shilex.android.assistant.VoiceSession
import app.shilex.android.orb.FloatingOrb
import app.shilex.android.ui.ShilexApp

class MainActivity : ComponentActivity() {
    private val assistant: AssistantViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { ShilexApp(assistant) }
        if (savedInstanceState == null) listenIfAsked(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        listenIfAsked(intent)
    }

    override fun onStart() {
        super.onStart()
        VoiceSession.get(this).screenVisible = true
        FloatingOrb.appVisible = true
        FloatingOrb.sync(this)
        // After a reboot or a kill, the wake-word listener comes back when the app is opened.
        if (VoiceService.wakeWordWanted(this)) VoiceService.start(this)
        askBatteryExemption()
    }

    /** Once: let ROSE run without battery limits, so a new message is noticed at once and not minutes later. */
    private fun askBatteryExemption() {
        val settings = Settings(this)
        if (settings.batteryAsked) return
        if (getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)) return
        settings.batteryAsked = true
        runCatching {
            startActivity(Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
    }

    // Leaving the screen no longer stops listening: VoiceService keeps the session going.
    override fun onStop() {
        super.onStop()
        VoiceSession.get(this).screenVisible = false
        FloatingOrb.appVisible = false
        FloatingOrb.sync(this)
    }

    /**
     * Opened as the phone's digital assistant (long-press / corner swipe): start listening
     * straight away, as long as the mic is already allowed and a key is saved.
     */
    private fun listenIfAsked(intent: Intent?) {
        if (intent?.action != Intent.ACTION_ASSIST) return
        val micAllowed = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        Diag.i("session: opened as assistant (mic allowed=$micAllowed)")
        if (!micAllowed || !assistant.state.value.hasKey) return
        // Never listen on a locked phone: whoever holds it could use the assistant.
        val keyguard = getSystemService(KeyguardManager::class.java)
        if (!keyguard.isKeyguardLocked) {
            assistant.start()
            return
        }
        Diag.i("session: phone locked, asking to unlock first")
        keyguard.requestDismissKeyguard(
            this,
            object : KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() = assistant.start()
            },
        )
    }
}
