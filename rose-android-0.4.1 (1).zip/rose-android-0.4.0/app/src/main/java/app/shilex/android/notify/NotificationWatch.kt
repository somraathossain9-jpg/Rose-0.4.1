package app.shilex.android.notify

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import app.shilex.android.Diag
import java.util.concurrent.ConcurrentHashMap

/**
 * Keeps the last notifications in memory so "what did I miss?" can be answered. Nothing is
 * stored on disk or logged (the log gets counts only), and nothing leaves the phone until the
 * user asks; then [Triage] sorts them and the model gets only its summary.
 */
class NotificationWatch : NotificationListenerService() {
    override fun onListenerConnected() {
        connected = true
        Diag.i("notifications: access on")
        if (app.shilex.android.data.Settings(this).autoReplyMode != AutoReply.OFF) MessageWatch.warm(this)
        // Messages that came while access was down are still in the shade: busy mode answers them now.
        runCatching {
            activeNotifications?.forEach { sbn -> keep(sbn)?.let { AutoReply.posted(this, it, catchUp = true) } }
        }
    }

    override fun onListenerDisconnected() {
        connected = false
        // Android may drop the listener to save battery; ask for it straight back so alerts stay instant.
        Diag.i("notifications: access dropped, rebinding")
        runCatching { requestRebind(ComponentName(this, NotificationWatch::class.java)) }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        keep(sbn)?.let {
            MessageWatch.posted(this, it)
            AutoReply.posted(this, it)
        }
    }

    private fun labelOf(pkg: String): String = labels.getOrPut(pkg) {
        runCatching { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() }.getOrDefault(pkg)
    }

    /** The other person's lines when the notification lists them (WhatsApp, Telegram, Messages…). */
    private fun linesOf(n: Notification): List<Msg> = runCatching {
        val style = NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(n) ?: return emptyList()
        val me = style.user.name?.toString()
        style.messages.mapNotNull { m ->
            val from = m.person?.name?.toString()
            val text = m.text?.toString()?.trim().orEmpty()
            if (m.person == null || (me != null && from == me) || text.isEmpty()) null else Msg(m.timestamp, text)
        }.takeLast(MAX_LINES)
    }.getOrDefault(emptyList())

    /** Remembers [sbn] and returns it as ROSE keeps it, or null when it isn't kept. */
    private fun keep(sbn: StatusBarNotification): Seen? {
        val n = sbn.notification ?: return null
        if (sbn.isOngoing || n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return null
        val extras = n.extras
        val label = labelOf(sbn.packageName)
        val group = extras.getBoolean(NotificationCompat.EXTRA_IS_GROUP_CONVERSATION) ||
            extras.getCharSequence(NotificationCompat.EXTRA_CONVERSATION_TITLE) != null
        val seen = Seen(
            packageName = sbn.packageName,
            app = label,
            title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty(),
            text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty(),
            atMillis = sbn.postTime,
            group = group,
            category = n.category.orEmpty(),
            messages = linesOf(n),
        ).let { s ->
            // Only people's own chats can be answered hands-free, never groups.
            if (group) s else s.copy(replyId = Replies.register(sbn.key, s.title.ifBlank { label }, label, sbn.packageName, n, sbn.postTime))
        }
        synchronized(recent) {
            recent.removeAll { it.atMillis < System.currentTimeMillis() - KEEP_MS }
            recent.add(seen)
            while (recent.size > MAX_KEPT) recent.removeAt(0)
        }
        return seen
    }

    companion object {
        private val recent = mutableListOf<Seen>()
        private val labels = ConcurrentHashMap<String, String>()
        private const val MAX_LINES = 6

        /** True while Android has the listener bound; the watchdog revives it when this is false. */
        @Volatile var connected = false
            private set
        private const val MAX_KEPT = 60
        private const val KEEP_MS = 12 * 60 * 60 * 1000L

        /** The kept notifications since [sinceMillis], oldest first. */
        fun since(sinceMillis: Long): List<Seen> = synchronized(recent) { recent.filter { it.atMillis >= sinceMillis } }

        fun clear() = synchronized(recent) { recent.clear() }

        /** Whether the user gave ROSE notification access in Android settings. */
        fun allowed(context: Context): Boolean {
            val me = ComponentName(context, NotificationWatch::class.java).flattenToString()
            return Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners").orEmpty().split(':').contains(me)
        }
    }
}
