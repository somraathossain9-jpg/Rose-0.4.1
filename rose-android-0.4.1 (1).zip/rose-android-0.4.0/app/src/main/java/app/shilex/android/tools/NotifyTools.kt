package app.shilex.android.tools

import app.shilex.android.Branding
import app.shilex.android.Diag
import app.shilex.android.data.Settings
import app.shilex.android.notify.AutoReply
import app.shilex.android.notify.MessageWatch
import app.shilex.android.notify.NotificationWatch
import app.shilex.android.notify.Replies
import app.shilex.android.notify.Triage
import org.json.JSONObject

/** "What did I miss?": recent notifications, sorted by [Triage] before the model sees them. */
object NotifyTools {
    fun all(): List<PhoneTool> = listOf(NotificationsCheck, WatchMessages, ReplyPrepare, ReplySend, AutoReplySet, ChatTakeOver)

    /** Step 1 of a hands-free reply: nothing is sent; the result is the line to read back. */
    private object ReplyPrepare : PhoneTool {
        override val name = "reply_prepare"

        override fun declaration() = Schema.function(
            name,
            "Prepares a reply to a message from notifications_check (its [reply N] id), without opening the app. " +
                "Sends nothing: read the returned line back to the user word for word and wait for their answer.",
            Schema.integer("reply_id", "The N from [reply N].", required = true),
            Schema.string("text", "The reply exactly as the user said it.", required = true),
        )

        override suspend fun run(args: JSONObject, host: ToolHost): JSONObject {
            val text = args.text("text").take(MAX_REPLY).ifEmpty { return Results.failed("no_text", "Ask what to reply.") }
            val line = Replies.prepare(args.optInt("reply_id", 0), text, System.currentTimeMillis())
                ?: return Results.failed("no_chat", "That message can't be answered from here any more. Offer to open the chat.")
            return Results.done("Say exactly: $line Then wait. Only if the user's answer is yes, call reply_send.")
        }
    }

    /** Step 2: sends only if the user's own words after the read-back were a clear yes. */
    private object ReplySend : PhoneTool {
        override val name = "reply_send"

        override fun declaration() = Schema.function(
            name,
            "Sends the reply prepared by reply_prepare, after the user answered yes. The phone checks their words itself.",
        )

        override suspend fun run(args: JSONObject, host: ToolHost): JSONObject =
            when (val outcome = Replies.send(host.context, System.currentTimeMillis())) {
                is Replies.Outcome.Sent -> Results.done("Sent to ${outcome.who} on ${outcome.app}.")
                is Replies.Outcome.Refused -> Results.failed("not_sent", outcome.why)
            }
    }

    /** Message mode: off, ask each time, or auto (busy: ROSE answers people itself). */
    private object AutoReplySet : PhoneTool {
        override val name = "auto_reply_set"

        override fun declaration() = Schema.function(
            name,
            "Sets how messages from people are handled: ask (read each aloud and ask whether to reply), " +
                "auto (the user is busy: reply to people by yourself as his assistant and keep chatting), or off.",
            Schema.string("mode", "ask, auto or off.", required = true),
            Schema.string("note", "Optional: what to tell people, e.g. he will call back at 5."),
        )

        override suspend fun run(args: JSONObject, host: ToolHost): JSONObject {
            val mode = args.text("mode").lowercase().trim()
            if (mode !in setOf("off", "ask", "auto")) return Results.failed("bad_mode", "The mode is ask, auto or off.")
            if (mode != "off" && !NotificationWatch.allowed(host.context)) return noAccess()
            val settings = Settings(host.context)
            settings.autoReplyMode = mode
            if (mode != "ask") AutoReply.modeChanged() // handed-over chats belong to Ask mode only
            if (mode != "off") settings.autoReplyNote = args.text("note").take(200)
            Diag.i("autoreply: mode $mode")
            return Results.done(
                when (mode) {
                    "auto" -> "Auto reply is on: ${Branding.ASSISTANT_NAME} answers people for the user. Say how to turn it off."
                    "ask" -> "From now each message is read out and the user is asked whether to reply."
                    else -> "Message replies are off."
                },
            )
        }
    }

    /**
     * Ask mode: "tumi kotha bolo" about the message just read out. ROSE answers that one person
     * herself from now on and tells the user what they write; everyone else is still asked about.
     */
    private object ChatTakeOver : PhoneTool {
        override val name = "chat_take_over"

        override fun declaration() = Schema.function(
            name,
            "The user hands ONE chat to you (\"tumi kotha bolo\", \"you talk to him\", \"tumi reply dao\" about a message " +
                "just read out): you answer that person yourself from now on, also their later messages, and the phone tells " +
                "the user what they wrote. Other people are still asked about first. Use release=true when the user wants to " +
                "answer that person himself again. Needs the notification access to be on and mode ask.",
            Schema.integer("reply_id", "The N from [reply N] of that message, if you know it."),
            Schema.string("name", "The person's name, if the user said it. Empty means the latest message read out."),
            Schema.string("note", "Optional: what the user wants you to tell them, e.g. he will call at 5."),
            Schema.string("release", "true to stop answering this person (or everyone handed over, if no name).", choices = listOf("true", "false")),
        )

        override suspend fun run(args: JSONObject, host: ToolHost): JSONObject {
            if (!NotificationWatch.allowed(host.context)) return noAccess()
            val id = args.optInt("reply_id", 0)
            val name = args.text("name")
            if (args.text("release").lowercase() == "true") {
                val n = AutoReply.giveBack(id, name)
                return if (n > 0) Results.done("Done. You no longer answer ${if (name.isBlank()) "those chats" else name}; the user is asked again.")
                else Results.failed("no_chat", "No chat was handed over.")
            }
            val settings = Settings(host.context)
            if (settings.autoReplyMode == "off") {
                return Results.failed("mode_off", "Messages are off. Switch to ask or auto first (auto_reply_set).")
            }
            val who = AutoReply.takeOver(host.context, id, name, args.text("note").take(200))
                ?: return Results.failed("no_chat", "That message can't be answered from here any more. Offer to open the chat.")
            Diag.i("autoreply: take over by voice")
            return Results.done("Done. From now you answer $who yourself and the phone tells the user what they write. Say so in one short line.")
        }
    }

    private fun noAccess() = Results.failed(
        "no_access",
        "${Branding.ASSISTANT_NAME} can't see notifications yet. Tell the user to turn on " +
            "Notification access in ${Branding.ASSISTANT_NAME} → Settings → Notifications.",
    )

    /** The "watch my messages" scene, see [MessageWatch]. */
    private object WatchMessages : PhoneTool {
        override val name = "watch_messages"

        override fun declaration() = Schema.function(
            name,
            "Starts or stops watching messages: for a while the phone stays quiet and says out loud only " +
                "who messaged or called (never what), and warns about links from unknown numbers. For 'keep an " +
                "eye on my messages', 'tell me if someone texts', 'stop watching'.",
            Schema.integer("minutes", "How long to watch; default 60, at most 180; 0 stops."),
        )

        override suspend fun run(args: JSONObject, host: ToolHost): JSONObject {
            val minutes = args.optInt("minutes", DEFAULT_WATCH_MIN).coerceIn(0, MAX_WATCH_MIN)
            if (minutes == 0) {
                MessageWatch.stop()
                return Results.done("Stopped watching messages.")
            }
            if (!NotificationWatch.allowed(host.context)) return noAccess()
            MessageWatch.start(minutes)
            val until = java.time.LocalTime.now().plusMinutes(minutes.toLong()).format(java.time.format.DateTimeFormatter.ofPattern("h:mm a"))
            return Results.done(
                "Watching until $until. The phone will say who messaged or called, not what; it stays quiet on silent " +
                    "or vibrate, and for groups and offers.",
            )
        }
    }

    private object NotificationsCheck : PhoneTool {
        override val name = "notifications_check"

        override fun declaration() = Schema.function(
            name,
            "What the user missed: messages and calls from people (name first), suspicious links, " +
                "codes (digits hidden) and a count of quiet ones (groups, offers). For 'what did I miss', " +
                "'any messages'.",
            Schema.integer("hours", "How far back to look; default 3, at most 12."),
        )

        override suspend fun run(args: JSONObject, host: ToolHost): JSONObject {
            if (!NotificationWatch.allowed(host.context)) return noAccess()
            val hours = args.optInt("hours", DEFAULT_HOURS).coerceIn(1, MAX_HOURS)
            val since = System.currentTimeMillis() - hours * HOUR_MS
            val items = Triage.sort(NotificationWatch.since(since), host.context.packageName)
            Diag.i("notifications: ${items.size} sorted, ${items.count { it.kind == Triage.Kind.Needs }} need the user")
            return Results.done("Last $hours h:\n" + Triage.summary(items))
        }
    }

    private const val DEFAULT_HOURS = 3
    private const val DEFAULT_WATCH_MIN = 60
    private const val MAX_WATCH_MIN = 180
    private const val MAX_REPLY = 500
    private const val MAX_HOURS = 12
    private const val HOUR_MS = 60 * 60 * 1000L
}
