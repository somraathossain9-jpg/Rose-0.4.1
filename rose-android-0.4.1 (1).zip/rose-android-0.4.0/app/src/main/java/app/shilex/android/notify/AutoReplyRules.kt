package app.shilex.android.notify

import org.json.JSONObject

/**
 * The pure rules behind busy-mode replies (no Android, so they are unit-tested): reading the
 * model's decision, refusing replies that must never go out, spotting messages that need no
 * answer, and tidying a chat's history.
 */
object AutoReplyRules {
    enum class Action { Reply, Skip, Urgent }

    /** What the model decided. [urgency] is 0..3; [summary] is a few words for the owner. */
    data class Decision(val action: Action, val reply: String, val urgency: Int, val summary: String)

    /** One line of a chat; [mine] is true for ROSE's own earlier reply. */
    data class Turn(val mine: Boolean, val text: String, val atMillis: Long = 0L)

    const val MAX_REPLY = 400
    const val MAX_SUMMARY = 90

    /** The decision in [raw] (JSON, possibly in a code fence), or plain text taken as a reply. */
    fun parse(raw: String): Decision? {
        val text = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        if (text.isEmpty()) return null
        if (!text.startsWith("{")) return Decision(Action.Reply, text, 0, "")
        val json = runCatching { JSONObject(text) }.getOrNull() ?: return null
        val action = when (json.optString("action").trim().lowercase()) {
            "skip", "ignore", "none" -> Action.Skip
            "urgent" -> Action.Urgent
            else -> Action.Reply
        }
        val urgency = json.optInt("urgency", if (action == Action.Urgent) 3 else 0).coerceIn(0, 3)
        return Decision(
            if (action == Action.Reply && urgency >= 3) Action.Urgent else action,
            json.optString("reply").trim(),
            urgency,
            json.optString("summary").replace(Regex("\\s+"), " ").trim().take(MAX_SUMMARY),
        )
    }

    private val LINK = Regex("""https?://|www\.|\b[a-z0-9-]+\.(com|net|org|me|ly|link|xyz|top|click|in|bd|app|io)\b""", RegexOption.IGNORE_CASE)
    private val LONG_NUMBER = Regex("""(?:[0-9০-৯][\s-]?){5,}""")
    private val SECRET_TALK = Regex(
        """\b(otp|password|passcode|cvv|pin code|card number|bkash|nagad|rocket|upi)\b|পাসওয়ার্ড|ওটিপি|পিন নম্বর|বিকাশ|নগদ""",
        RegexOption.IGNORE_CASE,
    )

    /**
     * The reply as it may be sent, or null when it must not go out: links, long numbers
     * (phone, card, code) or talk of codes, passwords and mobile money. The model is told this
     * too; this is the rule that holds when it slips.
     */
    fun sanitize(reply: String): String? {
        val flat = reply.replace(Regex("\\s*\\n\\s*"), " ").trim().trim('"', '“', '”').trim()
        if (flat.isEmpty()) return null
        if (LINK.containsMatchIn(flat) || LONG_NUMBER.containsMatchIn(flat) || SECRET_TALK.containsMatchIn(flat)) return null
        return flat.take(MAX_REPLY)
    }

    private val CLOSER = Regex(
        """^(ok+|okay|k|kk|thanks?( you)?|thx|ty|cool|fine|sure|got it|alright|hmm+|hm+|haan|han|acha|accha|theek hai|thik ache|thik ase|ठीक है|अच्छा|ধন্যবাদ|থ্যাংকস|থ্যাঙ্কস|ঠিক আছে|ঠিকাছে|আচ্ছা|ওকে|ওকে ধন্যবাদ|জি|হ্যাঁ|হুম)[\s.!।]*$""",
        RegexOption.IGNORE_CASE,
    )

    /** Only emoji and symbols, or a short closing word: nothing left to answer. */
    fun isCloser(text: String): Boolean {
        val t = text.trim()
        if (t.isEmpty()) return true
        if (t.none { it.isLetterOrDigit() }) return true
        return CLOSER.matches(t)
    }

    /** Neighbouring turns by the same side become one, so the model sees a clean back-and-forth. */
    fun merge(turns: List<Turn>): List<Turn> {
        val out = mutableListOf<Turn>()
        for (t in turns) {
            val last = out.lastOrNull()
            if (last != null && last.mine == t.mine) out[out.size - 1] = last.copy(text = last.text + "\n" + t.text, atMillis = t.atMillis)
            else out.add(t)
        }
        return out
    }

    /** A history the API accepts: starts and ends with the other person, at most [keep] turns. */
    fun forModel(turns: List<Turn>, keep: Int = 14): List<Turn> {
        var list = merge(turns).takeLast(keep)
        while (list.isNotEmpty() && list.first().mine) list = list.drop(1)
        while (list.isNotEmpty() && list.last().mine) list = list.dropLast(1)
        return list
    }

    /**
     * Chats the user handed over with "tumi kotha bolo" while in Ask mode. ROSE then answers
     * that one person by herself (and tells the user what they wrote); everyone else is still
     * asked about first. In memory only, and each hand-over ends after [ttlMs].
     */
    class Delegates(private val ttlMs: Long = DELEGATE_TTL_MS) {
        private class Entry(val until: Long, val note: String)

        private val chats = mutableMapOf<String, Entry>()

        @Synchronized
        fun add(key: String, note: String, now: Long) {
            chats[key] = Entry(now + ttlMs, note.trim())
        }

        @Synchronized
        fun has(key: String, now: Long): Boolean = live(key, now) != null

        /** What the user told ROSE to say to this person, or "" when nothing. */
        @Synchronized
        fun noteOf(key: String, now: Long): String = live(key, now)?.note.orEmpty()

        @Synchronized
        fun remove(key: String): Boolean = chats.remove(key) != null

        @Synchronized
        fun clear() = chats.clear()

        @Synchronized
        fun count(): Int = chats.size

        private fun live(key: String, now: Long): Entry? {
            val e = chats[key] ?: return null
            if (now > e.until) {
                chats.remove(key)
                return null
            }
            return e
        }
    }

    const val DELEGATE_TTL_MS = 12 * 60 * 60_000L

    /** The line ROSE says out loud when a message arrives and she answers it herself. */
    fun readOut(who: String, text: String, limit: Int = 160): String {
        val flat = text.replace(Regex("\\s+"), " ").trim()
        val short = if (flat.length <= limit) flat else flat.take(limit - 1).trimEnd() + "…"
        return "$who লিখেছেন: $short"
    }

    private val THANKS = Regex("""thanks?|thx|ty|ধন্যবাদ|থ্যাংকস|থ্যাঙ্কস""", RegexOption.IGNORE_CASE)

    /**
     * A short answer to a closing message (emoji, ok, thanks) for when the model can't be reached:
     * the same emoji back, "ওকে" for ok, a thank-you for thanks.
     */
    fun closerFallback(theirs: String): String {
        val t = theirs.trim()
        val bangla = BANGLA.containsMatchIn(t)
        return when {
            t.none { it.isLetterOrDigit() } -> t.take(8).ifEmpty { "🙂" }
            THANKS.containsMatchIn(t) -> if (bangla) "ধন্যবাদ, ভালো থাকবেন।" else "You're welcome!"
            else -> if (bangla) "ওকে" else "Ok"
        }
    }

    private val BANGLA = Regex("[\\u0980-\\u09FF]")

    /** A safe line when the model can't be reached or wrote something that may not be sent. */
    fun fallback(theirs: String, first: Boolean): String {
        val bangla = BANGLA.containsMatchIn(theirs)
        val english = !bangla && theirs.all { it.code < 128 } && Regex("\\b(the|is|are|you|please|call|where|when|what|hi|hello)\\b", RegexOption.IGNORE_CASE).containsMatchIn(theirs)
        return when {
            first && bangla -> "হ্যালো! আমি সম্রাটের অ্যাসিস্ট্যান্ট রোজ। উনি এখন একটু ব্যস্ত আছেন। আপনি কী বলতে চান, আমাকে বলতে পারেন।"
            first && english -> "Hello! I'm Rose, Somraat's assistant. He's busy right now. Tell me what it's about and I'll let him know."
            first -> "Hello! Ami Somraat-er assistant Rose. Uni ekhon ektu busy. Apni ki bolte chan, amake bolte paren."
            bangla -> "আমি ওনাকে জানিয়ে দিচ্ছি। ফ্রি হলেই উনি রিপ্লাই দেবেন।"
            english -> "I'll let him know. He'll reply as soon as he's free."
            else -> "Ami onake janiye dichchi. Free hoyei uni reply debe."
        }
    }
}
