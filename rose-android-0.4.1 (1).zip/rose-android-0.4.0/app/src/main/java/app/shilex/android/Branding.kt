package app.shilex.android

/** User-visible names, mirroring `src/shilex/branding.py`. Change both on a rename. */
object Branding {
    const val ASSISTANT_NAME = "ROSE"

    /** Who ROSE works for; used when it answers other people for the owner. */
    const val OWNER = "Somraat Islam Srabon"
}
