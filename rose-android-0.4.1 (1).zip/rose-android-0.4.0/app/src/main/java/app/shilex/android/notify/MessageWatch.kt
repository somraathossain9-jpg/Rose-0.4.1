package app.shilex.android.notify

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import app.shilex.android.Diag
import app.shilex.android.assistant.VoiceSession
import java.util.Locale

/**
 * The "watch my messages" scene: for a while, ROSE stays quiet and says out loud only when
 * a person needs the user ([WatchRules]). Runs on the phone with its own voice; nothing goes
 * to Gemini, and nothing is kept after the watch ends.
 */
object MessageWatch {
    @Volatile var untilMillis = 0L
        private set
    private var rules = WatchRules()
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ready = false
    private var keepWarm = false
    private val queued = mutableListOf<Pair<String, Boolean>>()

    val watching: Boolean get() = System.currentTimeMillis() < untilMillis

    fun start(minutes: Int) {
        untilMillis = System.currentTimeMillis() + minutes * 60_000L
        rules = WatchRules()
        Diag.i("watch: on for $minutes min")
    }

    fun stop() {
        untilMillis = 0L
        main.post(::shutDown)
        Diag.i("watch: off")
    }

    /** Called by [NotificationWatch] for every new notification. */
    fun posted(context: Context, n: Seen) {
        if (!watching || n.packageName == context.packageName) return
        val audio = context.getSystemService(AudioManager::class.java)
        val silent = audio.ringerMode != AudioManager.RINGER_MODE_NORMAL
        val line = rules.decide(n, System.currentTimeMillis(), silent, VoiceSession.get(context).active) ?: return
        Diag.i("watch: speaking up")
        main.post { say(context.applicationContext, line) }
    }

    /**
     * Starts the phone's voice ahead of time (main thread work, kept alive), so the first spoken
     * line of a new message doesn't wait for the engine to start.
     */
    fun warm(context: Context) {
        main.post {
            keepWarm = true
            if (tts == null) open(context.applicationContext)
        }
    }

    /** Says [line] aloud in Bangla with the phone's own voice (used when a message can't start a conversation). */
    fun announce(context: Context, line: String) {
        main.post { say(context.applicationContext, line, bangla = true) }
    }

    private fun TextToSpeech.pick(bangla: Boolean) {
        val bn = Locale("bn", "BD")
        language = if (bangla && isLanguageAvailable(bn) >= TextToSpeech.LANG_AVAILABLE) bn else Locale("en", "IN")
    }

    private fun say(context: Context, line: String, bangla: Boolean = false) {
        val voice = tts
        if (voice != null && ready) {
            voice.pick(bangla)
            voice.speak(line, TextToSpeech.QUEUE_ADD, null, "watch")
            return
        }
        // The engine is still starting: the line waits and is spoken the moment it is ready.
        queued.add(line to bangla)
        if (voice == null) open(context)
    }

    private fun open(context: Context) {
        lateinit var voice: TextToSpeech
        voice = TextToSpeech(context) { status ->
            main.post {
                if (status != TextToSpeech.SUCCESS) {
                    Diag.w("watch: no voice")
                    queued.clear()
                    tts = null
                    return@post
                }
                voice.setAudioAttributes(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build(),
                )
                ready = true
                val waiting = queued.toList()
                queued.clear()
                waiting.forEach { (line, bangla) ->
                    voice.pick(bangla)
                    voice.speak(line, TextToSpeech.QUEUE_ADD, null, "watch")
                }
            }
        }
        tts = voice
    }

    private fun shutDown() {
        if (keepWarm) return // message replies are on: keep the voice ready for the next one
        tts?.shutdown()
        tts = null
        ready = false
        queued.clear()
    }
}
