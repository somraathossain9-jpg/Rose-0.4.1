package app.shilex.android.tools

import app.shilex.android.Diag
import app.shilex.android.control.ControlService
import app.shilex.android.control.ScreenElement
import app.shilex.android.task.TaskTracker
import kotlinx.coroutines.delay

/**
 * Was a message really sent? Only what the screen shows counts: the text sits in the chat
 * and no longer in the typing box. Opening the chat with the text typed in is not "sent".
 */
object SendCheck {
    fun sent(elements: List<ScreenElement>, message: String): Boolean {
        val head = key(message)
        if (head.isEmpty()) return false
        val stillTyped = elements.any { it.role == "field" && head in key(it.value) }
        val inChat = elements.any { it.role != "field" && head in key(it.label) }
        return inChat && !stillTyped
    }

    private fun key(text: String) = text.lowercase().filter { it.isLetterOrDigit() }.take(40)

    /**
     * Watches WhatsApp for up to [timeoutMs] after it opens; tells the task and the model what
     * really happened. Needs phone control; without it the result stays "you tap Send".
     */
    suspend fun watchWhatsApp(message: String, timeoutMs: Long = 90_000L): String? {
        val service = ControlService.instance ?: return null
        val until = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < until) {
            delay(1_500)
            val snap = service.snapshot() ?: continue
            if (snap.packageName !in WHATSAPP) continue
            if (sent(snap.elements, message)) {
                TaskTracker.verified(true, "Sent: the message now shows in the chat.")
                return "The phone saw the message appear in the WhatsApp chat, so it was sent."
            }
        }
        TaskTracker.verified(false, "Not seen as sent. If you still want it, tap Send in WhatsApp.")
        return "The message was not seen as sent. Don't tell the user it was sent."
    }

    private val WHATSAPP = setOf("com.whatsapp", "com.whatsapp.w4b")
    private val SEND_LABEL = Regex("^(send( message| sms)?|भेजें)$", RegexOption.IGNORE_CASE)
    private val CALL_LABEL = Regex("^(call|dial|voice call|audio call)$", RegexOption.IGNORE_CASE)

    /**
     * Auto-allow: once [packages] is in front with exactly [message] typed in the box, presses its
     * Send button. Never types or sends anything else. Returns a note for the model, or null.
     */
    suspend fun autoSend(packages: Set<String>, message: String, timeoutMs: Long = 25_000L): String? {
        val service = ControlService.instance ?: return null
        val until = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < until) {
            delay(1_200)
            if (service.overlay.stopped) return null
            val snap = service.snapshot() ?: continue
            if (snap.packageName !in packages) continue
            val typed = snap.elements.any { it.role == "field" && key(message).let { head -> head.isNotEmpty() && head in key(it.value) } }
            if (!typed) continue
            val button = service.findFirst { it.isClickable && SEND_LABEL.matches(service.labelOf(it).trim()) } ?: continue
            if (service.click(button)) {
                Diag.i("control: send auto-pressed")
                return if (snap.packageName in WHATSAPP) watchWhatsApp(message, 15_000L) else "The Send button was pressed for the user."
            }
        }
        return "The Send button wasn't found, so the user taps Send in the app. Don't say it was sent."
    }

    /** Auto-allow: presses Call in the dialer once it shows the number. */
    suspend fun autoCall(dialers: Set<String>, timeoutMs: Long = 15_000L): String? {
        val service = ControlService.instance ?: return null
        val until = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < until) {
            delay(1_000)
            if (service.overlay.stopped) return null
            val snap = service.snapshot() ?: continue
            if (snap.packageName !in dialers) continue
            val button = service.findFirst { it.isClickable && CALL_LABEL.matches(service.labelOf(it).trim()) } ?: continue
            if (service.click(button)) {
                Diag.i("control: call auto-pressed")
                return "The Call button was pressed for the user."
            }
        }
        return "The Call button wasn't found, so the user taps Call in the dialer."
    }
}
