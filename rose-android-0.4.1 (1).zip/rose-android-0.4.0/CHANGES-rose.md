# Rose 0.4.1

- Busy mode no longer stays silent on ok, thanks or emoji: "ok" gets "ওকে", thanks gets "ধন্যবাদ", an emoji gets a fitting
  emoji (and, from the chat so far, a few words: sad gets "কী হয়েছে?"). To stop endless ok-ok, a second closing message
  right after such an answer gets none; a real message resets it. Spam, bots and abuse are still skipped.
- Ask mode can hand ONE chat over: after Rose reads a message out, say "tumi kotha bolo" (or "tumi reply dao") and she
  answers that person herself, also their later messages, and says out loud what they wrote ("X লিখেছেন: …", then
  "আমি উত্তর দিয়ে দিয়েছি।") instead of asking again. Other people are still asked about first. New tool chat_take_over
  (also by name, with an optional note, and release=true to take the chat back). Hand-overs are kept in memory, end after
  12 hours, and are cleared when the mode changes to Off or Auto.
- Auto (busy) mode reads each message out first, then answers. Nothing is spoken on silent or vibrate or while Rose is
  already talking with you.
- Faster message handling: the phone's voice is started ahead of time (the first spoken line no longer waits for the
  engine), a burst of messages waits 0.7 s (was 1.2 s) and the backup model starts after 1.5 s (was 2.5 s).
- The settings text for Messages describes the three modes.

# Rose 0.4.0

- New face and logo: the glowing particle sphere (see docs/logo.png). The orb is now thousands of dots on a turning
  sphere with a bright rim and folding ribbons of light; it swells with the voice and moves most while speaking.
  New launcher icon (adaptive, with a themed monochrome version). Default colour is magenta/violet.
- 33 moods (was 20): romantic, dreamy, playful, focused, serious, energetic, peaceful, mysterious, brave, hopeful,
  lonely, magical, sweet added. The orb takes its colours from the mood.
- Notifications are seen sooner: a 15-minute watchdog (Notify/Watchdog) rebinds notification access when Android drops
  it, messages that arrived while access was down are answered on reconnect (busy mode, last 30 min), chat
  notifications are read line by line (all new messages, not only the last), more chat apps are recognised
  (Messenger Lite, imo, Viber, Signal, Telegram X), and the lag of each message is written to the diagnostic log.
- Smarter busy-mode replies (notify/AutoReply, AutoReplyRules):
  - Fixed: replies could be cut off or empty because the model's "thinking" used the output budget. Thinking is now off.
  - A burst of messages gets one answer (1.2 s wait), not one per message.
  - The model chooses: reply, stay silent (thanks, ok, emoji, bots, spam) or urgent (replies and alerts you with a
    notification and a spoken line). It sees the time, whether the sender is a saved contact, how the chat went and when
    it last replied, so it does not repeat itself or re-introduce itself.
  - Understands voice messages and photos, asks, money/code/link requests, and answers in the sender's language and tone.
  - Faster: models race (the next starts after 2.5 s if the first is slow); a stuck call is cancelled.
  - A code guard refuses any reply with a link, a long number, or talk of OTP/passwords/bKash/Nagad; a safe line is sent
    instead. Busy mode still never answers groups, codes or links.
  - Busy-mode replies now appear in Activity with a few words on what the person wanted.
- bKash, Nagad and Upay apps are blocked from phone control like banking apps.

# Rose 0.3.0

- Long-term memory: notes kept up to 2000 (was 200), the latest 40 are given to Rose at the start of every
  conversation, she saves lasting facts by herself, and never deletes anything unless told to forget it.
- Messages from people (Settings -> Messages): "Ask me" reads each message out and asks whether to reply
  (the spoken yes is still checked by the phone); "Auto (busy)" answers people by itself as the owner's
  assistant, keeps chatting (Gemini writes each reply), max 8 replies an hour per chat, never groups, codes or links.
  The tool auto_reply_set lets you switch it by voice ("tumi reply dite thako").
- Faster message alerts: the notification listener rebinds itself when Android drops it, and the app asks once
  to be excluded from battery optimisation.
- Bangla is the default reply language (Bangladeshi Bangla); the Bangla voice reads messages aloud.
- Persona: Rose is a girl character and a caring friend; owner name is Somraat Islam Srabon.

# Changes since the Jarvis -> Rose rename

- Voice picker (female voices first, default Kore), reply language incl. Bangla/Banglish, model name field (Settings).
- Bangla (bn-IN) added to speech recognition, so what you say appears in Bangla script.
- Talk over reacts sooner (TalkOver quick settings in VoiceSession).
- "Send and call without asking" (default off): only plain Send/Call in messaging apps and the dialer
  (ControlRules.autoAllowed). Payments, delete, OTP, passwords and banking apps still need you.
- Friendly mode: jokes, playful arguments, calls the owner Boss / Samrat Boss / Shrabon / Sir.
- 20 moods (assistant/Mood.kt) via the silent set_mood tool; the orb changes colour and has a 3D look (ui/Orb.kt).
- Instructions v9: careful listening and checking each tool result.
